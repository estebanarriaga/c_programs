#ifndef __MISIL_H__
#define __MISIL_H__

#include "tipos.h"
misil_t CrearMisil();


#endif
