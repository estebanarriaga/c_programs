#include "misil.h"

////////////////////////////////////////////////////////
//Función para crear un misil con valores por defecto (todo a 0).

misil_t CrearMisil(){
	misil_t misil;
	misil.danio=0;
	misil.direccion=ascendente;
	return misil;
}
