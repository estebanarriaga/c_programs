#ifndef __MISIL_H__
#define __MISIL_H__

#include "tipos.h"
misil_t CrearMisil();
void mueveMisil(objeto_t* objeto, int numFilas, int numColumnas); 

#endif
