#include "objetos.h"
#include "misil.h"
#include "personaje.h"
#include "enemigo.h"
#include "tipos.h"

////////////////////////////////////////////////////////////
//Añadir la función para crear un objeto de un tipo dado. Inicializa sus valores "tipo",
//"sprite" y "posición" dependiendo del tipo indicado. La posición por defecto es "X=0" "Y=0"
//
// Por defecto, los objetos creados están activos (la variable "activo"=1) 

objeto_t CrearObjeto(enum tipoObjeto_e tipo){}
