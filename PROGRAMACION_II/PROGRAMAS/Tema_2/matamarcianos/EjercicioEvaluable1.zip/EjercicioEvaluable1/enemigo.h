#ifndef __ENEMIGO_H__
#define __ENEMIGO_H__

#include "tipos.h"

enemigo_t CrearEnemigo();

#endif
