#include "misil.h"

////////////////////////////////////////////////////////
//Añadir la función para crear un misil con valores por defecto (todo a 0, dirección ascendente).

