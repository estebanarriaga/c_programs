#ifndef __OBJETOS_H__
#define __OBJETOS_H__
#include "tipos.h"

objeto_t CrearObjeto(tipoObjeto_e tipo);


#endif
