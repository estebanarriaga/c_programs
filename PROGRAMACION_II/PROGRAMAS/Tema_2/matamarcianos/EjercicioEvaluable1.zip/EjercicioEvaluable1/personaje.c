#include "personaje.h"


////////////////////////////////////////////////////////
//Añadir función para crear un personaje con valores por defecto (todo a 0).


