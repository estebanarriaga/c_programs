#ifndef __PERSONAJE_H__
#define __PERSONAJE_H__
#include "tipos.h"

personaje_t CrearPersonajePrincipal();

#endif
