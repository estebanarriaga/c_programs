#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "objetos.h"
#include "tablero.h"


/////////////////////////////////////////////////
// Programa principal

int main(int argc, char** argv)
{

	//crear un array doble de tamaño "NFILAS"x"NCOLUMNAS" de tipo "objeto_t", llamado "tablero.

	//iniciar el tablero (llamar a la función indicada)
	//dibujar el tablero (llamar a la función indicada
	
	//terminar

}



