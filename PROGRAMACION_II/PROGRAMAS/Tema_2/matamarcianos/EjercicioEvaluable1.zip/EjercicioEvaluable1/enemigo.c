#include "enemigo.h"

////////////////////////////
//Añadir función para crear un enemigo con valores por defecto (todo a 0).


